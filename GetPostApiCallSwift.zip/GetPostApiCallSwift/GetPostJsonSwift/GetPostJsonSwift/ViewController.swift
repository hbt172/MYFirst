

import UIKit

class ViewController: UIViewController {
    var arrMusicAlbum :[[String:AnyObject]] = [[:]]
    override func viewDidLoad() {
        super.viewDidLoad()
        // get
        ApiCall.sharedInstance.requestGetMethod(apiUrl: "http://xyz/../api/xyz") { (success, responseData) in
            print(responseData ?? AnyObject.self)
        }
        
        
        // Post
        let postString = "offset=0&page=0&user_id=1"
        let paramData = postString.data(using: .utf8)
        ApiCall.sharedInstance.requestPostMethod(apiUrl: "http://xyz/../api/xyz", params: paramData!) { (success, responseData) in
            print(responseData ?? AnyObject.self)
            
            let status = (responseData! ["status"]) as? Int
            let message  = (responseData! ["message"]) as! NSString
            if status == 1{
                DispatchQueue.main.async {
                    let StrUserid = (responseData!["user_id"]) as! NSString
                    let emailID = (responseData!["user_email"]) as! NSString
                    
                  self.arrMusicAlbum = responseData?["music_album"] as! [AnyObject] as! [[String : AnyObject]]
                 
//                    self.tableViewAlbumCategory.reloadData()
                    print(message)
                }
            }
            else {
                DispatchQueue.main.async {
                     print(message)
                                   }
            }

        }
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

